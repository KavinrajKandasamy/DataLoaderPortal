import logo from "./logo.svg";
import "./App.css";
import Login from "./components/Login";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import Dashboard from "./components/Logout"
import AddPatient from "./components/Addpatient";
import EditPatient from "./components/Editpatient";
import Process from "./components/Process";
import LogOut from "./components/Logout";

function App() {
  return (
    <div>
      
      <BrowserRouter>
        <Route exact path="/login" component={Login} />
		<Route exact path="/" component={Login} />
    <Route exact path='/homepage' component={LogOut} />
    <Route exact path="/add" component={AddPatient}/>
    <Route exact path="/edit" component={EditPatient}/>
    <Route exact path="/process" component={Process}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
