import React from "react";
import "../App.css";
import "../Addpatient.css"
import { useHistory } from "react-router-dom";


const AddPatient = () => {
    const history = useHistory();
    const [add, setAdd] = React.useState('true');


    return (
        <>
            <div>
                <h2>Student Registration Form Using Table in HTML</h2>
                <br></br>
                <table align="left" cellpadding="50">
                    <tr>
                        <td>First Name</td>
                        <td><input type="text" name="FirstName" maxlength="50" placeholder="Ghanendra" />
                        </td>
                    </tr>

                    <tr>
                        <td>Last Name</td>
                        <td><input type="text" name="LastName" maxlength="50" placeholder="Yadav" />
                        </td>
                    </tr>
                </table>
            </div>
        </>

    )
};
export default AddPatient;