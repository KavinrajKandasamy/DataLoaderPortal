import React from "react";
import "../App.css";
import { useHistory } from "react-router-dom";


const Process = () => {
    const history = useHistory();
    const [process,setProcess] = React.useState('true');

    
return (
    <>
        <h1>Process the Details</h1>
    </>
)
};
export default Process;