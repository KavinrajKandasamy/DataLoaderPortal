import React from "react";
import "../App.css";
import { useHistory, withRouter, NavLink } from "react-router-dom";
import BasicExample from "../components/Navbar";

const LogOut = () => {
  const history = useHistory();
  const [logout, setLogout] = React.useState(false);

  React.useEffect(() => {
    //history.push("/login");
    // if (!localStorage.getItem("auth")) history.push("/login");
  });

  const AddHandler = (e) => {
    history.push('/add')
    e.preventDefault();
  }
  const EditHandler = (e) => {
    history.push('/edit')
    e.preventDefault();
  }
  const ProcessHandler = (e) => {
    history.push('/process')
    e.preventDefault();
  }

  const logoutHandler = (e) => {
    e.preventDefault();
    localStorage.removeItem("auth");
    setLogout(true);
  };

  return (
    
      <div>
        
        {/* <div className="container-login100" style={{ backgroundImage: 'url("https://cdn.wallpapersafari.com/46/54/fJc5OX.jpg")' }}>
          <div className="container">
            <div className="row">
              <div className="col-md-3">
                <button onClick={AddHandler} to="/add" className="btn btn-primary">Add</button>
              </div>
              <div className="col-md-3">
                <button onClick={EditHandler} to="/edit" className="btn btn-primary">Edit</button>
              </div>
              <div className="col-md-3">
                <button onClick={ProcessHandler} to="/process" className="btn btn-primary">Process</button>
              </div>
              <div className="col-md-3">
                <button onClick={logoutHandler} to="/logout" className="btn btn-primary text-left">Logout</button>
              </div>

            </div>
          </div>
        </div> */}

<div class="topnav">
  <a href="Add" onClick={AddHandler}>Add</a>
  <a href="Edit" onClick={EditHandler}>Edit</a>
  <a href="Process" onClick={ProcessHandler}>Process</a>
</div>
      </div>
  );
};




export default LogOut;
