import React from "react";
import "../App.css";
import { useHistory } from "react-router-dom";


const EditPatient = () => {
    const history = useHistory();
    const [edit,setEdit] = React.useState('true');

    
return (
    <>
        <h1>Edit Patient Details</h1>
    </>
)
};
export default EditPatient;