
import firebase from "firebase/app";
import "firebase/database";


const firebaseConfig = {
  apiKey: "AIzaSyCilfaqK4KMIxocRX9DtpxieYYODqsFbDU",
  authDomain: "loginauth-514a3.firebaseapp.com",
  projectId: "loginauth-514a3",
  storageBucket: "loginauth-514a3.appspot.com",
  messagingSenderId: "579973442054",
  appId: "1:579973442054:web:0683433334e4edabf47187",
  measurementId: "G-CVCEZTMCD4"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const databaseRef = firebase.database().ref()
export const notesRef = databaseRef.child("notes")
export default firebase;